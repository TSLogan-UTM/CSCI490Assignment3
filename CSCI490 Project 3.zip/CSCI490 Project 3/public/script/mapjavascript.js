var customers = [];
var selectedCustomer = null;
var theMap;
var theGeocoder;

// geocoding
// https://developers.google.com/maps/documentation/javascript/geocoding

function addCustomersToMap() {
   for (cKey in customers) {
    let c = customers[cKey];
        addCustomerToMap(c);
    }
}

function latLangToLatLngLiteral(latLang) {
    var latLangArray = latLang.split(':');
    var lat = parseFloat(latLangArray[0]);
    var lng = parseFloat(latLangArray[1]);
    return {
        lat: lat,
        lng: lng
    };
}

function addCustomerToMap(customer) {
    var latLang = customer.latLang;
    if (!latLang) {
        console.log('No latLang for: ', customer.name);
        return;
    }
    customer.mapMarker = addPinToMap(latLangToLatLngLiteral(latLang));
}

function addPinToMap(latLng) {
    var marker = new google.maps.Marker({
        map: theMap,
        position: latLng
    });

    google.maps.event.addListener(marker, 'click', function() {
        theMap.setZoom(9);
        theMap.setCenter(marker.getPosition());
    });

    return marker;
}

function updateCustomers(newCustomers) {
    customers = newCustomers;
    redrawCustomerDiv();
    setTimeout(() => {
        addCustomersToMap();
    }, 1000);
}

function observingCustomersOnFirebase() {
    var database = firebase.database();

    
    var customersRef = firebase.database().ref("csci490-ass3-930ea/");
    customersRef.on('value', function(snapshot) {
        let data = snapshot.val();
        updateCustomers(data);
    });
}

function addCustomerToDB(c) {
    var database = firebase.database();
    var customersRef = firebase.database().ref("csci490-ass3-930ea/");
    customersRef.push(c);
}

async function zoomMapToMarker(marker) {
    if (!marker) {
        console.log('No marker!');
        return;
    }
    theMap.setZoom(5);
    await sleep(500);
    theMap.setCenter(marker.getPosition());
    await sleep(1000);
    theMap.setZoom(9);
}

function showCustomer(cNum) {
    let c = customers[cNum];
    selectedCustomer = c;
    zoomMapToMarker(c.mapMarker);
    redrawPicDiv(selectedCustomer);
}

function showAddDialog() {
    const modal = document.querySelector('.my-modal');
    modal.showModal();
}

function closeDialog() {
    const modal = document.querySelector('.my-modal');
    modal.close();
}

function closeAndSave() {
    let customer = {};
    customer.name = document.getElementById('nameField').value;
    customer.address = document.getElementById('addressField').value;
    customer.cityStateZip = document.getElementById('cityField').value + ', ' + document.getElementById('stateField').value + ' ' + document.getElementById('zipField').value;
    closeDialog();
    addCustomerToTop(customer);
}

function addCustomerToTop(c) {
    customers = [c, ...customers];
    redrawCustomerDiv();

    setTimeout(() => {
        geocodeCustomer(c, (loc) => {
            if (loc) {
                c.latLang = loc.lat() + ":" + loc.lng();
                addCustomerToMap(c);
                redrawCustomerDiv();
                zoomMapToMarker(c.mapMarker);
            }
        });
    }, 1000);
}

function geocodeCustomer(customer, callBack) {
    var address = customer.address + " " + customer.cityStateZip;
    geocodeAddress(address, callBack);
}

function geocodeAddress(address, callBack) {

    theGeocoder.geocode({
        'address': address
    }, function(results, status) {
        if (status == 'OK') {
            var loc = results[0].geometry.location;
            callBack(loc);
        } else {
            console.log('Geocode was not successful for the following reason: ' + status);
            callBack(null);
        }
    });
}

function addToCustomers(name, address, cityStateZip) {
    var aObject = {
        name: name,
        address: address,
        cityStateZip: cityStateZip
    }
    customers.push(aObject);
}

function redrawPicDiv(selectedCustomer) {
    let e = document.getElementById('pictDiv');
    console.log('Debug redrawPicDiv here');
    if (!selectedCustomer) {
        e.innerHTML = '<h1>No selected user</h1>';
        return;
    } else if (!selectedCustomer.image) {
        e.innerHTML = '<h2>No Image</h2>';
    } else {
        e.innerHTML = `<img style='max-width:290;' src='${selectedCustomer.image}'>`;
    }

    e.innerHTML += `<div>${selectedCustomer.name}</div>`;
    e.innerHTML += `<div>${selectedCustomer.address}</div>`;
    e.innerHTML += `<div>${selectedCustomer.cityStateZip}</div>`;
}

function redrawCustomerDiv() {
    var div = document.getElementById('div1');
    var newHTML = `<table border=1 id='my_table'>
					<thead>
					<tr>
					
					<th>Name</th>
					<th>Address</th>
					<th>CityStateZip</th>
					<th>Lat Lang</th>
					</tr>
					</thead>
					<tbody>`;
    let count = 0;
    for (cKey in customers) {
        let c = customers[cKey];
        newHTML += `<tr><td>${c.name}</td><td>${c.address}</td><td>${c.cityStateZip}</td><td>${c.latLang}</td></tr>`
    }

    newHTML += '</tbody></table>';

    div.innerHTML = newHTML;
    $('#my_table').DataTable();
    //console.log(JSON.stringify(customers));
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}


 